<?php
$con = mysqli_connect('localhost','root','root','spirosys')

?>